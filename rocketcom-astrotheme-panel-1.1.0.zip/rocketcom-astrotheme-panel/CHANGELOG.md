# Changelog

## 1.0.6

- Adds monospace font to clock
- Updates logo to use black font
- Adds `skipDataQuery` option to plugin.json. The panel no longer requires or asks for a query.

## 1.0.5

- Updates links
- Updates required Grafana version

## 1.0.0 (Unreleased)

Initial release.
